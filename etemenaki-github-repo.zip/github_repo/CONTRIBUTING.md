# Contributing to ETEMENAKI

Thank you for your interest in contributing to ETEMENAKI. This document outlines how to contribute effectively.

## Core Principles

ETEMENAKI follows the ML Innovations "We DO" philosophy. Contributions should be production-ready, tested, and complete. No half measures.

## How to Contribute

### Reporting Issues

Open a GitHub Issue with:
- What you expected to happen
- What actually happened
- Browser and OS information
- Screenshot if relevant

### Content Contributions

The highest-impact contributions are deepening level content. Each level should have 4 genuinely unique code examples that teach different aspects of the topic.

When writing level content:
- All code must be syntactically correct in Python, JavaScript, AND Rust
- Examples should build progressively within the level (simple → complex)
- Practice validators must check for specific keywords relevant to the concept, never just code length
- Game questions should test understanding, not memorization
- Assessment questions should require real comprehension

### Code Contributions

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/your-feature`)
3. Make your changes
4. Test by opening the HTML file in Chrome, Firefox, and Safari
5. Submit a Pull Request with a clear description

### Style Guide

ETEMENAKI is a single-file application. All HTML, CSS, and JavaScript live in one file.

- CSS: Use CSS variables defined in `:root` for colors
- JavaScript: No frameworks, vanilla JS only
- Level Data: JSON structure with strict field requirements (see below)

### Level Data Schema

Every level must contain:
```json
{
  "id": 1,
  "title": "Storage & Types",
  "tier": 1,
  "tierName": "FOUNDATION",
  "pattern": "STORAGE",
  "patternColor": "#4A90E2",
  "patternEmoji": "📦",
  "description": "Names hold values...",
  "examples": [4 items],
  "practices": [4 items],
  "games": [4 items],
  "challenge": {1 item},
  "assessment": [5 items]
}
```

### Practice Validator Rules

Every practice `check` field must use `code.includes()` to verify the student wrote relevant code. Pure length checks (`code.length > 20`) are not acceptable.

Good: `"code.includes('def') && code.includes('return') && code.includes('if')"`
Bad: `"code.length > 30"`

## Code of Conduct

Be respectful, constructive, and focused on making ETEMENAKI better for learners. Technical disagreements should be resolved with evidence and testing, not authority.

## Contact

M. L. McKnight — ml.innovations.research.lab@gmail.com

---

ML Innovations LLC — Pheba, Mississippi
